# Kurye Yönetim Sistemi\n\nB2B Kurye Operasyon Platformu
