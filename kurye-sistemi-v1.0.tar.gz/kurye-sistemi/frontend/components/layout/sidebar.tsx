"use client";

import { Package, Users, Utensils, BarChart3, Settings, HelpCircle, ChevronRight, Menu, X, CreditCard } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { cn } from "@/lib/utils";

const menuItems = [
  {
    icon: Package,
    label: "Siparişler",
    href: "/orders",
    subItems: [
      { label: "Güncel Siparişler", href: "/orders/current" },
      { label: "Geçmiş Siparişler", href: "/orders/history" },
    ],
  },
  { icon: Users, label: "Kuryeler", href: "/couriers" },
  { icon: Utensils, label: "Restoranlar", href: "/restaurants" },
  { icon: Users, label: "Kullanıcılar", href: "/users" },
  {
    icon: BarChart3,
    label: "Raporlar",
    href: "/reports",
    subItems: [
      { label: "Teslimat Performans", href: "/reports/performance" },
      { label: "Kurye Hakediş", href: "/reports/courier" },
      { label: "Restoran Hakediş", href: "/reports/restaurant" },
      { label: "Ödeme Dağılım", href: "/reports/payment" },
      { label: "Firma Hakediş", href: "/reports/company" },
    ],
  },
  {
    icon: Settings,
    label: "Ayarlar",
    href: "/settings",
    subItems: [
      { label: "Genel Ayar", href: "/settings/general" },
      { label: "Atama & Havuz", href: "/settings/assignment" },
      { label: "Bölgelendirme", href: "/settings/zones" },
      { label: "Mola Yönetim", href: "/settings/breaks" },
      { label: "Bildirimler", href: "/settings/notifications" },
      { label: "Vardiyalar", href: "/settings/shifts" },
      { label: "Kontör Yönetim", href: "/settings/credits" },
    ],
  },
  { icon: HelpCircle, label: "Yardım / Destek", href: "/help" },
];

export function Sidebar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(true);
  const [expanded, setExpanded] = useState<string[]>(["Siparişler"]);
  const [mobileOpen, setMobileOpen] = useState(false);

  const toggleExpand = (label: string) => {
    setExpanded((prev) =>
      prev.includes(label) ? prev.filter((l) => l !== label) : [...prev, label]
    );
  };

  const isActive = (href: string) => pathname === href || pathname?.startsWith(href);

  return (
    <>
      {/* Mobile Toggle */}
      <button
        onClick={() => setMobileOpen(!mobileOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-[#5B3FD9] text-white rounded-lg shadow-lg"
      >
        {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed left-0 top-0 h-screen bg-gradient-to-b from-[#5B3FD9] to-[#4a32b5] text-white transition-all duration-300 z-40 shadow-2xl",
          open ? "w-64" : "w-20",
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Logo */}
        <div className="flex items-center justify-between p-5 border-b border-white/10">
          <div className={cn("transition-all", open ? "opacity-100" : "opacity-0 w-0 overflow-hidden")}>
            <h1 className="text-xl font-bold tracking-tight">Paketçiniz</h1>
            <p className="text-xs text-white/60">Bodrum</p>
          </div>
          <button
            onClick={() => setOpen(!open)}
            className="hidden lg:flex p-1.5 hover:bg-white/10 rounded-lg transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="p-3 space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const hasSubItems = item.subItems && item.subItems.length > 0;
            const isExpanded = expanded.includes(item.label);

            return (
              <div key={item.label}>
                <Link
                  href={hasSubItems ? "#" : item.href}
                  onClick={(e) => {
                    if (hasSubItems) {
                      e.preventDefault();
                      if (open) toggleExpand(item.label);
                    }
                  }}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 group",
                    isActive(item.href)
                      ? "bg-white/20 text-white shadow-lg shadow-black/10"
                      : "text-white/70 hover:bg-white/10 hover:text-white"
                  )}
                >
                  <Icon className={cn("w-5 h-5 flex-shrink-0", isActive(item.href) && "text-white")} />
                  <span
                    className={cn(
                      "text-sm font-medium flex-1 transition-all whitespace-nowrap",
                      open ? "opacity-100 w-auto" : "opacity-0 w-0 overflow-hidden"
                    )}
                  >
                    {item.label}
                  </span>
                  {hasSubItems && open && (
                    <ChevronRight
                      className={cn("w-4 h-4 transition-transform duration-200", isExpanded && "rotate-90")}
                    />
                  )}
                </Link>

                {/* Submenu */}
                {hasSubItems && open && isExpanded && (
                  <div className="ml-4 mt-1 space-y-0.5 animate-in slide-in-from-top-2 duration-200">
                    {item.subItems?.map((sub) => (
                      <Link
                        key={sub.href}
                        href={sub.href}
                        className={cn(
                          "flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all",
                          isActive(sub.href)
                            ? "bg-white/10 text-white font-medium"
                            : "text-white/50 hover:text-white hover:bg-white/5"
                        )}
                      >
                        <ChevronRight className="w-3 h-3" />
                        {sub.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Credit Display */}
        <div className={cn("absolute bottom-0 left-0 right-0 p-4 border-t border-white/10", !open && "hidden")}>
          <div className="bg-white/10 rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <CreditCard className="w-4 h-4 text-white/60" />
              <span className="text-xs text-white/60">Kontör Bakiye</span>
            </div>
            <p className="text-2xl font-bold text-white">948 <span className="text-sm font-normal text-white/60">TL</span></p>
            <p className="text-xs text-white/40 mt-1">379 teslimat hakkı</p>
          </div>
        </div>
      </aside>

      {/* Mobile Overlay */}
      {mobileOpen && <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setMobileOpen(false)} />}

      {/* Main Content Spacer */}
      <div className={cn("hidden lg:block transition-all duration-300", open ? "w-64" : "w-20")} />
    </>
  );
}
