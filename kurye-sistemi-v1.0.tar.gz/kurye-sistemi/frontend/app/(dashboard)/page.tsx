"use client";

import { useState } from "react";
import dynamic from "next/dynamic";
import { Package, Users, MapPin, Clock, Search, Filter, Grid3X3, List } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

// Leaflet dynamic import for SSR
const MapWithNoSSR = dynamic(() => import("@/components/dashboard/map"), {
  ssr: false,
  loading: () => (
    <div className="h-[400px] bg-gray-100 rounded-2xl flex items-center justify-center">
      <div className="animate-spin w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full" />
    </div>
  ),
});

const courierStats = {
  total: 7,
  active: 0,
  onDelivery: 1,
  passive: 6,
};

const orders = [
  // Mock data - normally from API
];

export default function DashboardPage() {
  const [viewMode, setViewMode] = useState<"list" | "grid">("list");
  const [activeTab, setActiveTab] = useState("waiting");

  return (
    <div className="p-6 space-y-6">
      {/* Map Section */}
      <Card className="overflow-hidden border-0 shadow-xl">
        <CardContent className="p-0">
          <div className="relative">
            {/* Courier Stats Overlay */}
            <div className="absolute top-4 left-4 z-[400] bg-white rounded-xl shadow-lg p-4 min-w-[280px]">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-[#5B3FD9] flex items-center justify-center">
                    <Users className="w-4 h-4 text-white" />
                  </div>
                  <span className="font-semibold text-gray-900">Kuryeler ({courierStats.total})</span>
                </div>
              </div>

              <div className="flex gap-2">
                <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                  Aktif ({courierStats.active})
                </Badge>
                <Badge variant="secondary" className="bg-orange-100 text-orange-700">
                  Yolda ({courierStats.onDelivery})
                </Badge>
                <Badge variant="secondary" className="bg-gray-100 text-gray-700">
                  Pasif ({courierStats.passive})
                </Badge>
              </div>

              <p className="text-sm text-gray-500 mt-3 text-center py-2 bg-gray-50 rounded-lg">
                Çevrimiçi kurye bulunmuyor
              </p>
            </div>

            {/* Map */}
            <MapWithNoSSR />
          </div>
        </CardContent>
      </Card>

      {/* Orders Section */}
      <Card className="border-0 shadow-lg">
        <CardContent className="p-6">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="bg-gray-100 p-1">
                <TabsTrigger
                  value="waiting"
                  className="data-[state=active]:bg-[#5B3FD9] data-[state=active]:text-white rounded-lg px-4 py-2"
                >
                  <div className="flex items-center gap-2">
                    <span>Bekleyen Siparişler</span>
                    <Badge className="bg-white text-gray-700">0</Badge>
                  </div>
                </TabsTrigger>
                <TabsTrigger
                  value="onway"
                  className="data-[state=active]:bg-[#5B3FD9] data-[state=active]:text-white rounded-lg px-4 py-2"
                >
                  <div className="flex items-center gap-2">
                    <span>Yoldaki Siparişler</span>
                    <Badge className="bg-white text-gray-700">1</Badge>
                  </div>
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Ara..."
                  className="pl-9 pr-4 py-2 bg-gray-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 w-40"
                />
              </div>
              <Button variant="outline" size="icon" className="rounded-lg">
                <Filter className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-lg">
                <List className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-lg">
                <Grid3X3 className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Table Header */}
          <div className="grid grid-cols-7 gap-4 px-4 py-3 bg-gray-50 rounded-t-xl text-xs font-medium text-gray-500 uppercase tracking-wider">
            <div>Sipariş</div>
            <div>Müşteri</div>
            <div>Restoran</div>
            <div>Adres</div>
            <div>Mesafe</div>
            <div>Saat</div>
            <div>Durum</div>
          </div>

          {/* Empty State */}
          <div className="py-16 text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
              <Package className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-gray-500">Bu kategoride sipariş bulunmamaktadır</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
