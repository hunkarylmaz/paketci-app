import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Company } from '../../companies/entities/company.entity';

export enum CreditTransactionType {
  PURCHASE = 'purchase',           // Kontör satın alma
  DELIVERY_DEDUCTION = 'delivery_deduction', // Teslimat kesintisi
  REFUND = 'refund',               // İade
  BONUS = 'bonus',                 // Bonus/hediye
  ADJUSTMENT = 'adjustment',       // Manuel düzeltme
}

export enum CreditStatus {
  COMPLETED = 'completed',
  PENDING = 'pending',
  FAILED = 'failed',
  CANCELLED = 'cancelled',
}

@Entity('credits')
export class Credit {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  companyId: string;

  @ManyToOne(() => Company, company => company.credits)
  @JoinColumn({ name: 'companyId' })
  company: Company;

  @Column({ type: 'enum', enum: CreditTransactionType })
  type: CreditTransactionType;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  amount: number; // Pozitif: yükleme, Negatif: kullanım

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  balanceAfter: number; // İşlem sonrası bakiye

  @Column({ type: 'enum', enum: CreditStatus, default: CreditStatus.COMPLETED })
  status: CreditStatus;

  @Column({ nullable: true })
  deliveryId: string; // Teslimat kesintisi için

  @Column({ nullable: true })
  paymentId: string; // Ödeme referansı

  @Column({ nullable: true })
  paymentMethod: string; // iyzico, stripe, havale...

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column()
  createdBy: string; // İşlemi yapan kullanıcı

  @CreateDateColumn()
  createdAt: Date;
}
