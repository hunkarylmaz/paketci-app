import { Controller, Get, Post, Body, UseGuards, Request, Param } from '@nestjs/common';
import { CreditsService } from './credits.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('credits')
@UseGuards(JwtAuthGuard)
export class CreditsController {
  constructor(private creditsService: CreditsService) {}

  @Get('balance')
  async getBalance(@Request() req) {
    return this.creditsService.getBalance(req.user.companyId);
  }

  @Get('transactions')
  async getTransactions(@Request() req) {
    return this.creditsService.getTransactions(req.user.companyId);
  }
}
