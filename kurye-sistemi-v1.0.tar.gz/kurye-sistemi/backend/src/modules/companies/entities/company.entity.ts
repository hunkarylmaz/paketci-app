import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, OneToMany } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Restaurant } from '../../restaurants/entities/restaurant.entity';
import { Courier } from '../../couriers/entities/courier.entity';
import { Credit } from '../../credits/entities/credit.entity';

export enum CompanyStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  SUSPENDED = 'suspended',
  PENDING_PAYMENT = 'pending_payment',
}

@Entity('companies')
export class Company {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  code: string; // Bayi kodu: KRY001, KRY002...

  @Column()
  name: string;

  @Column({ nullable: true })
  commercialName: string;

  @Column({ nullable: true })
  taxNumber: string;

  @Column({ nullable: true })
  taxOffice: string;

  @Column({ nullable: true })
  address: string;

  @Column({ nullable: true })
  city: string;

  @Column({ nullable: true })
  district: string;

  @Column({ nullable: true })
  phone: string;

  @Column({ nullable: true })
  email: string;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  creditBalance: number; // Mevcut kontör bakiyesi

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 2.50 })
  deliveryFeePerOrder: number; // Teslimat başına düşen kontör (default: 2.5 TL)

  @Column({ type: 'enum', enum: CompanyStatus, default: CompanyStatus.PENDING_PAYMENT })
  status: CompanyStatus;

  @Column({ type: 'jsonb', nullable: true })
  settings: {
    autoAssignCourier: boolean;
    notifyCustomers: boolean;
    requirePhotoProof: boolean;
    maxDeliveryDistance: number; // km
  };

  @OneToMany(() => User, user => user.company)
  users: User[];

  @OneToMany(() => Restaurant, restaurant => restaurant.company)
  restaurants: Restaurant[];

  @OneToMany(() => Courier, courier => courier.company)
  couriers: Courier[];

  @OneToMany(() => Credit, credit => credit.company)
  credits: Credit[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
