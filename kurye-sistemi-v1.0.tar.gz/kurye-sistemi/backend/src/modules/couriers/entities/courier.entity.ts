import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn, OneToOne } from 'typeorm';
import { Company } from '../../companies/entities/company.entity';
import { User } from '../../users/entities/user.entity';

export enum CourierStatus {
  AVAILABLE = 'available',
  BUSY = 'busy',
  OFFLINE = 'offline',
  ON_BREAK = 'on_break',
}

export enum CourierVehicleType {
  MOTORCYCLE = 'motorcycle',
  BICYCLE = 'bicycle',
  CAR = 'car',
  SCOOTER = 'scooter',
  WALK = 'walk',
}

@Entity('couriers')
export class Courier {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column({ unique: true })
  phone: string;

  @Column({ nullable: true })
  email: string;

  @Column({ type: 'enum', enum: CourierVehicleType, default: CourierVehicleType.MOTORCYCLE })
  vehicleType: CourierVehicleType;

  @Column({ nullable: true })
  vehiclePlate: string;

  @Column({ nullable: true })
  licenseNumber: string;

  @Column({ type: 'enum', enum: CourierStatus, default: CourierStatus.OFFLINE })
  status: CourierStatus;

  @Column({ type: 'decimal', precision: 10, scale: 8, nullable: true })
  currentLatitude: number;

  @Column({ type: 'decimal', precision: 11, scale: 8, nullable: true })
  currentLongitude: number;

  @Column({ type: 'timestamp', nullable: true })
  locationUpdatedAt: Date;

  @Column({ default: 0 })
  totalDeliveries: number;

  @Column({ type: 'decimal', precision: 3, scale: 2, default: 5.00 })
  rating: number;

  @Column({ nullable: true })
  userId: string;

  @OneToOne(() => User, user => user.courier)
  @JoinColumn({ name: 'userId' })
  user: User;

  @Column()
  companyId: string;

  @ManyToOne(() => Company, company => company.couriers)
  @JoinColumn({ name: 'companyId' })
  company: Company;

  @Column({ type: 'jsonb', nullable: true })
  documents: {
    idCard?: string;
    driverLicense?: string;
    vehicleRegistration?: string;
    insurance?: string;
  };

  @Column({ type: 'timestamp', nullable: true })
  lastActiveAt: Date;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
