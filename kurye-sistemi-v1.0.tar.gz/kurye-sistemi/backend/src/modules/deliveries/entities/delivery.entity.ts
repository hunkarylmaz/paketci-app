import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Company } from '../../companies/entities/company.entity';
import { Restaurant } from '../../restaurants/entities/restaurant.entity';
import { Courier } from '../../couriers/entities/courier.entity';

export enum DeliveryStatus {
  PENDING = 'pending',           // Bekliyor
  ASSIGNED = 'assigned',         // Kuryeye atandı
  ACCEPTED = 'accepted',         // Kurye kabul etti
  PICKED_UP = 'picked_up',       // Paket alındı
  IN_TRANSIT = 'in_transit',     // Yolda
  NEAR_DESTINATION = 'near_destination', // Yaklaştı
  DELIVERED = 'delivered',       // Teslim edildi
  CANCELLED = 'cancelled',       // İptal edildi
  FAILED = 'failed',             // Teslimat başarısız
}

export enum PaymentType {
  CASH = 'cash',
  CREDIT_CARD = 'credit_card',
  ONLINE = 'online',
  MEAL_CARD = 'meal_card',
}

@Entity('deliveries')
export class Delivery {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  trackingNumber: string; // Takip numarası: KRY-240317-XXXX

  @Column()
  restaurantId: string;

  @ManyToOne(() => Restaurant, restaurant => restaurant.deliveries)
  @JoinColumn({ name: 'restaurantId' })
  restaurant: Restaurant;

  @Column()
  companyId: string;

  @ManyToOne(() => Company, company => company.deliveries)
  @JoinColumn({ name: 'companyId' })
  company: Company;

  @Column({ nullable: true })
  courierId: string;

  @ManyToOne(() => Courier, courier => courier.deliveries)
  @JoinColumn({ name: 'courierId' })
  courier: Courier;

  // Müşteri bilgileri
  @Column()
  customerName: string;

  @Column()
  customerPhone: string;

  @Column()
  deliveryAddress: string;

  @Column({ nullable: true })
  deliveryCity: string;

  @Column({ nullable: true })
  deliveryDistrict: string;

  @Column({ nullable: true })
  deliveryNeighborhood: string;

  @Column({ type: 'decimal', precision: 10, scale: 8, nullable: true })
  deliveryLatitude: number;

  @Column({ type: 'decimal', precision: 11, scale: 8, nullable: true })
  deliveryLongitude: number;

  @Column({ type: 'text', nullable: true })
  deliveryNotes: string;

  // Sipariş detayları
  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  orderAmount: number;

  @Column({ type: 'enum', enum: PaymentType, default: PaymentType.CASH })
  paymentType: PaymentType;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  cashAmount: number; // Kapıda ödenecek tutar

  // Durum ve zamanlar
  @Column({ type: 'enum', enum: DeliveryStatus, default: DeliveryStatus.PENDING })
  status: DeliveryStatus;

  @Column({ type: 'timestamp', nullable: true })
  assignedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  acceptedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  pickedUpAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  deliveredAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  estimatedDeliveryTime: Date;

  // Kontör ve ücretlendirme
  @Column({ type: 'decimal', precision: 10, scale: 2 })
  creditDeducted: number; // Düşülen kontör (genellikle 2.5 TL)

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  courierEarnings: number; // Kurye kazancı

  // Kanıt ve doğrulama
  @Column({ nullable: true })
  deliveryPhoto: string; // Teslimat fotoğrafı

  @Column({ nullable: true })
  customerSignature: string; // Müşteri imzası (base64)

  @Column({ nullable: true })
  cancellationReason: string;

  @Column({ nullable: true })
  failureReason: string;

  // Mesafe ve süre
  @Column({ type: 'decimal', precision: 8, scale: 2, nullable: true })
  totalDistance: number; // km

  @Column({ nullable: true })
  totalDuration: number; // dakika

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
