export class CreateDeliveryDto {
  restaurantId: string;
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  deliveryCity?: string;
  deliveryDistrict?: string;
  deliveryNeighborhood?: string;
  deliveryLatitude?: number;
  deliveryLongitude?: number;
  deliveryNotes?: string;
  orderAmount: number;
  paymentType?: string;
  cashAmount?: number;
  createdBy?: string;
}

export class UpdateDeliveryStatusDto {
  status: string;
  courierId?: string;
  deliveryPhoto?: string;
  customerSignature?: string;
  cancellationReason?: string;
  failureReason?: string;
}
