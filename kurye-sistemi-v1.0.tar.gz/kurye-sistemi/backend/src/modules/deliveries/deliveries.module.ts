import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DeliveriesService } from './deliveries.service';
import { DeliveriesController } from './deliveries.controller';
import { Delivery } from './entities/delivery.entity';
import { Company } from '../companies/entities/company.entity';
import { Credit } from '../credits/entities/credit.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Delivery, Company, Credit])],
  providers: [DeliveriesService],
  controllers: [DeliveriesController],
  exports: [DeliveriesService],
})
export class DeliveriesModule {}
