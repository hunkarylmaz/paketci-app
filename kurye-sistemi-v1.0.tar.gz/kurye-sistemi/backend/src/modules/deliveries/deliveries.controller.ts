import { 
  Controller, 
  Get, 
  Post, 
  Patch, 
  Body, 
  Param, 
  Query, 
  UseGuards, 
  Request 
} from '@nestjs/common';
import { DeliveriesService } from './deliveries.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CreateDeliveryDto } from './dto/create-delivery.dto';
import { UpdateDeliveryStatusDto } from './dto/update-delivery-status.dto';

@Controller('deliveries')
@UseGuards(JwtAuthGuard)
export class DeliveriesController {
  constructor(private deliveriesService: DeliveriesService) {}

  @Post()
  async create(@Body() createDto: CreateDeliveryDto, @Request() req) {
    return this.deliveriesService.create(req.user.companyId, {
      ...createDto,
      createdBy: req.user.userId,
    });
  }

  @Get()
  async findAll(@Query() filters, @Request() req) {
    return this.deliveriesService.findAll(req.user.companyId, filters);
  }

  @Get('stats')
  async getStats(@Request() req) {
    return this.deliveriesService.getStats(req.user.companyId);
  }

  @Get(':id')
  async findOne(@Param('id') id: string, @Request() req) {
    return this.deliveriesService.findOne(req.user.companyId, id);
  }

  @Patch(':id/status')
  async updateStatus(
    @Param('id') id: string,
    @Body() updateDto: UpdateDeliveryStatusDto,
    @Request() req,
  ) {
    return this.deliveriesService.updateStatus(
      req.user.companyId, 
      id, 
      updateDto,
      req.user.userId
    );
  }
}
