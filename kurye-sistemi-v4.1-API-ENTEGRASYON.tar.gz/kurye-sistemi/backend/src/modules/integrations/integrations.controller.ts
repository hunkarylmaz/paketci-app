import { Controller, Get, Post, Put, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { IntegrationsService } from './integrations.service';
import { CreatePlatformConfigDto } from './dto/create-platform-config.dto';
import { UpdatePlatformStatusDto } from './dto/update-platform-status.dto';

@ApiTags('Integrations')
@Controller('integrations')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class IntegrationsController {
  constructor(private readonly integrationsService: IntegrationsService) {}

  @Get('platforms')
  @ApiOperation({ summary: 'Get all available platforms' })
  getPlatforms() {
    return this.integrationsService.getPlatforms();
  }

  @Get('restaurants/:restaurantId/platforms')
  @ApiOperation({ summary: 'Get restaurant platform configurations' })
  getRestaurantPlatforms(@Param('restaurantId') restaurantId: string) {
    return this.integrationsService.getRestaurantPlatforms(restaurantId);
  }

  @Post('restaurants/:restaurantId/platforms')
  @ApiOperation({ summary: 'Configure platform for restaurant' })
  configurePlatform(
    @Param('restaurantId') restaurantId: string,
    @Body() dto: CreatePlatformConfigDto,
  ) {
    return this.integrationsService.configurePlatform(restaurantId, dto);
  }

  @Put('restaurants/:restaurantId/platforms/:platformId/status')
  @ApiOperation({ summary: 'Toggle platform open/close status' })
  togglePlatformStatus(
    @Param('restaurantId') restaurantId: string,
    @Param('platformId') platformId: string,
    @Body() dto: UpdatePlatformStatusDto,
  ) {
    return this.integrationsService.togglePlatformStatus(restaurantId, platformId, dto);
  }

  @Post('restaurants/:restaurantId/platforms/:platformId/sync')
  @ApiOperation({ summary: 'Sync orders from platform' })
  syncOrders(
    @Param('restaurantId') restaurantId: string,
    @Param('platformId') platformId: string,
  ) {
    return this.integrationsService.syncOrders(restaurantId, platformId);
  }

  @Post('restaurants/:restaurantId/platforms/:platformId/orders/:orderId/accept')
  @ApiOperation({ summary: 'Accept order from platform' })
  acceptOrder(
    @Param('restaurantId') restaurantId: string,
    @Param('platformId') platformId: string,
    @Param('orderId') orderId: string,
  ) {
    return this.integrationsService.acceptOrder(restaurantId, platformId, orderId);
  }
}
