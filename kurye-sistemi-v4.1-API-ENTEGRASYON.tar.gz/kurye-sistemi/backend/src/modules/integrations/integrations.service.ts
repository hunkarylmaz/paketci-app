import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PlatformIntegration, PlatformType } from './entities/platform-integration.entity';
import { RestaurantPlatformConfig, PlatformStatus } from './entities/restaurant-platform-config.entity';
import { YemeksepetiAdapter } from './adapters/yemeksepeti.adapter';
import { GetirAdapter } from './adapters/getir.adapter';
import { CreatePlatformConfigDto } from './dto/create-platform-config.dto';
import { UpdatePlatformStatusDto } from './dto/update-platform-status.dto';

@Injectable()
export class IntegrationsService {
  private readonly logger = new Logger(IntegrationsService.name);

  constructor(
    @InjectRepository(PlatformIntegration)
    private platformRepo: Repository<PlatformIntegration>,
    @InjectRepository(RestaurantPlatformConfig)
    private configRepo: Repository<RestaurantPlatformConfig>,
    private yemeksepetiAdapter: YemeksepetiAdapter,
    private getirAdapter: GetirAdapter,
  ) {}

  // Initialize default platforms on module init
  async initializePlatforms() {
    const platforms = [
      {
        platformType: PlatformType.YEMEK_SEPETI,
        name: 'Yemeksepeti',
        apiBaseUrl: 'https://api.yemeksepeti.com/v2',
        defaultCommissionRate: 18.0,
      },
      {
        platformType: PlatformType.GETIR_YEMEK,
        name: 'Getir Yemek',
        apiBaseUrl: 'https://api.getir.com/yemek/v1',
        defaultCommissionRate: 15.0,
      },
      {
        platformType: PlatformType.GETIR_CARSI,
        name: 'Getir Çarşı',
        apiBaseUrl: 'https://api.getir.com/carsi/v1',
        defaultCommissionRate: 17.0,
      },
      {
        platformType: PlatformType.MIGROS_YEMEK,
        name: 'Migros Yemek',
        apiBaseUrl: 'https://api.migrosyemek.com.tr/v1',
        defaultCommissionRate: 16.0,
      },
      {
        platformType: PlatformType.TRENDYOL_YEMEK,
        name: 'Trendyol Yemek',
        apiBaseUrl: 'https://api.trendyolyemek.com/v1',
        defaultCommissionRate: 15.5,
      },
    ];

    for (const platform of platforms) {
      const exists = await this.platformRepo.findOne({
        where: { platformType: platform.platformType },
      });
      if (!exists) {
        await this.platformRepo.save(this.platformRepo.create(platform));
      }
    }
  }

  // Get all platforms
  async getPlatforms() {
    return this.platformRepo.find({ where: { isActive: true } });
  }

  // Get restaurant platform configurations
  async getRestaurantPlatforms(restaurantId: string) {
    return this.configRepo.find({
      where: { restaurantId },
      relations: ['platform'],
    });
  }

  // Configure platform for restaurant
  async configurePlatform(restaurantId: string, dto: CreatePlatformConfigDto) {
    const platform = await this.platformRepo.findOne({
      where: { id: dto.platformId },
    });

    if (!platform) {
      throw new NotFoundException('Platform not found');
    }

    let config = await this.configRepo.findOne({
      where: { restaurantId, platformId: dto.platformId },
    });

    if (!config) {
      config = this.configRepo.create({
        restaurantId,
        platformId: dto.platformId,
      });
    }

    // Update credentials
    config.apiKey = dto.apiKey;
    config.apiSecret = dto.apiSecret;
    config.merchantId = dto.merchantId;
    config.branchId = dto.branchId;
    config.settings = dto.settings;
    config.webhookUrl = dto.webhookUrl;

    // Test authentication
    const isAuthenticated = await this.authenticatePlatform(config);
    
    if (isAuthenticated) {
      config.status = PlatformStatus.CONNECTED;
    } else {
      config.status = PlatformStatus.ERROR;
      config.lastErrorMessage = 'Authentication failed';
    }

    return this.configRepo.save(config);
  }

  // Toggle platform open/close status
  async togglePlatformStatus(
    restaurantId: string,
    platformId: string,
    dto: UpdatePlatformStatusDto,
  ) {
    const config = await this.configRepo.findOne({
      where: { restaurantId, platformId },
      relations: ['platform'],
    });

    if (!config) {
      throw new NotFoundException('Platform configuration not found');
    }

    config.isOpen = dto.isOpen;
    config.autoAcceptOrders = dto.autoAcceptOrders ?? config.autoAcceptOrders;

    // Update platform status via API
    const adapter = this.getAdapter(config.platform.platformType);
    if (adapter) {
      const success = await adapter.toggleRestaurantStatus(config, dto.isOpen);
      if (!success) {
        config.lastErrorMessage = 'Failed to update platform status';
      }
    }

    return this.configRepo.save(config);
  }

  // Sync orders from platform
  async syncOrders(restaurantId: string, platformId: string) {
    const config = await this.configRepo.findOne({
      where: { restaurantId, platformId },
      relations: ['platform'],
    });

    if (!config || config.status !== PlatformStatus.CONNECTED) {
      throw new NotFoundException('Platform not connected');
    }

    const adapter = this.getAdapter(config.platform.platformType);
    if (!adapter) {
      throw new NotFoundException('Platform adapter not found');
    }

    const orders = await adapter.getOrders(config);
    config.lastSyncAt = new Date();
    await this.configRepo.save(config);

    return orders;
  }

  // Accept order
  async acceptOrder(restaurantId: string, platformId: string, orderId: string) {
    const config = await this.configRepo.findOne({
      where: { restaurantId, platformId },
      relations: ['platform'],
    });

    const adapter = this.getAdapter(config.platform.platformType);
    return adapter.acceptOrder(config, orderId);
  }

  // Private helper methods
  private async authenticatePlatform(config: RestaurantPlatformConfig): Promise<boolean> {
    const adapter = this.getAdapter(config.platform?.platformType);
    if (!adapter) return false;
    return adapter.authenticate(config);
  }

  private getAdapter(platformType: PlatformType) {
    switch (platformType) {
      case PlatformType.YEMEK_SEPETI:
        return this.yemeksepetiAdapter;
      case PlatformType.GETIR_YEMEK:
      case PlatformType.GETIR_CARSI:
        return this.getirAdapter;
      // Add other adapters as they are implemented
      default:
        return null;
    }
  }
}
