import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HttpModule } from '@nestjs/axios';
import { IntegrationsService } from './integrations.service';
import { IntegrationsController } from './integrations.controller';
import { PlatformIntegration } from './entities/platform-integration.entity';
import { RestaurantPlatformConfig } from './entities/restaurant-platform-config.entity';
import { YemeksepetiAdapter } from './adapters/yemeksepeti.adapter';
import { GetirAdapter } from './adapters/getir.adapter';
import { TrendyolAdapter } from './adapters/trendyol.adapter';
import { MigrosAdapter } from './adapters/migros.adapter';
import { PosIntegration } from './entities/pos-integration.entity';
import { HardwareIntegration } from './entities/hardware-integration.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      PlatformIntegration,
      RestaurantPlatformConfig,
      PosIntegration,
      HardwareIntegration,
    ]),
    HttpModule,
  ],
  controllers: [IntegrationsController],
  providers: [
    IntegrationsService,
    YemeksepetiAdapter,
    GetirAdapter,
    TrendyolAdapter,
    MigrosAdapter,
  ],
  exports: [IntegrationsService],
})
export class IntegrationsModule {}
