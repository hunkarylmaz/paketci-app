"use client";

import { useState } from "react";
import { MapPin, Phone, Clock, CheckCircle2, XCircle, Navigation, Camera, Package, Star, DollarSign, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

// Kurye uygulaması - mobil görünüm
const currentDelivery = {
  id: "KRY-240317-001",
  customer: "Ali Veli",
  phone: "0555 123 4567",
  address: "Cumhuriyet Mah. Atatürk Cad. No:15, D:3",
  restaurant: "Burger King",
  orderAmount: 285.50,
  paymentType: "Nakit",
  notes: "Apartman girişinde zil çalmayın",
  estimatedTime: "12 dk",
  distance: "2.3 km",
};

const todayStats = {
  completed: 12,
  earnings: 350,
  rating: 4.8,
  onlineHours: 6.5,
};

export default function CourierAppPage() {
  const [status, setStatus] = useState<"waiting" | "picked_up" | "delivered">("waiting");

  return (
    <div className="min-h-screen bg-slate-50 max-w-md mx-auto">
      {/* Status Bar */}
      <div className="bg-blue-600 text-white p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="font-medium">Çevrimiçi</span>
          </div>
          <Badge className="bg-white/20 text-white">{todayStats.completed} Teslimat</Badge>
        </div>
        <div className="mt-4 flex items-center justify-between">
          <div>
            <p className="text-sm text-blue-100">Bugünkü Kazanç</p>
            <p className="text-3xl font-bold">{todayStats.earnings}₺</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-100">Değerlendirme</p>
            <div className="flex items-center gap-1">
              <Star className="w-5 h-5 text-yellow-300 fill-yellow-300" />
              <span className="text-2xl font-bold">{todayStats.rating}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Active Delivery */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-slate-900">Aktif Teslimat</h2>
          <span className="text-sm text-slate-500">#{currentDelivery.id}</span>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          {/* Restaurant Info */}
          <div className="p-4 bg-slate-50 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                <Package className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-slate-900">{currentDelivery.restaurant}</p>
                <p className="text-sm text-slate-500">Paket hazır</p>
              </div>
              <Button size="sm" variant="outline">
                <Navigation className="w-4 h-4 mr-1" />
                Yol Tarifi
              </Button>
            </div>
          </div>

          {/* Customer Info */}
          <div className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center">
                <span className="font-semibold text-slate-600">{currentDelivery.customer.charAt(0)}</span>
              </div>
              <div className="flex-1">
                <p className="font-medium text-slate-900">{currentDelivery.customer}</p>
                <a
                  href={`tel:${currentDelivery.phone}`}
                  className="text-sm text-blue-600 flex items-center gap-1 mt-1"
                >
                  <Phone className="w-4 h-4" /
                  {currentDelivery.phone}
                </a>
              </div>
            </div>

            <div className="mt-4 p-3 bg-slate-50 rounded-xl">
              <div className="flex items-start gap-2">
                <MapPin className="w-5 h-5 text-slate-400 mt-0.5" />
                <div>
                  <p className="text-sm text-slate-900">{currentDelivery.address}</p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
                    <span className="flex items-center gap-1">
                      <Navigation className="w-3 h-3" /
                      {currentDelivery.distance}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /
                      {currentDelivery.estimatedTime}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {currentDelivery.notes && (
              <div className="mt-3 p-3 bg-yellow-50 border border-yellow-100 rounded-xl">
                <p className="text-sm text-yellow-800">📝 {currentDelivery.notes}</p>
              </div>
            )}

            <div className="mt-4 flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-500">Sipariş Tutarı</p>
                <p className="text-xl font-bold text-slate-900">{currentDelivery.orderAmount}₺</p>
              </div>
              <Badge className="bg-green-100 text-green-700">{currentDelivery.paymentType}</Badge>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="p-4 border-t border-slate-100 space-y-3">
            {status === "waiting" && (
              <Button
                className="w-full h-14 text-lg bg-blue-600 hover:bg-blue-700"
                onClick={() => setStatus("picked_up")}
              >
                <Package className="w-5 h-5 mr-2" />
                Paketi Aldım
              </Button>
            )}

            {status === "picked_up" && (
              <>
                <Button
                  className="w-full h-14 text-lg bg-blue-600 hover:bg-blue-700"
                  onClick={() => setStatus("delivered")}
                >
                  <CheckCircle2 className="w-5 h-5 mr-2" />
                  Teslim Ettim
                </Button>
                <Button variant="outline" className="w-full h-12">
                  <Camera className="w-5 h-5 mr-2" />
                  Fotoğraf Çek
                </Button>
              </>
            )}

            {status === "delivered" && (
              <div className="text-center py-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <CheckCircle2 className="w-8 h-8 text-green-600" />
                </div>
                <p className="font-semibold text-slate-900">Teslimat Tamamlandı!</p>
                <p className="text-sm text-slate-500 mt-1">+29₺ kazancınız eklendi</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 pb-6">
        <div className="grid grid-cols-2 gap-3">
          <Button variant="outline" className="h-14 justify-start">
            <DollarSign className="w-5 h-5 mr-2 text-green-600" />
            <div className="text-left">
              <p className="text-xs text-slate-500">Günlük</p>
              <p className="font-semibold">{todayStats.earnings}₺</p>
            </div>
          </Button>

          <Button variant="outline" className="h-14 justify-start">
            <Clock className="w-5 h-5 mr-2 text-blue-600" />
            <div className="text-left">
              <p className="text-xs text-slate-500">Çalışma</p>
              <p className="font-semibold">{todayStats.onlineHours}s</p>
            </div>
          </Button>
        </div>
      </div>
    </div>
  );
}
